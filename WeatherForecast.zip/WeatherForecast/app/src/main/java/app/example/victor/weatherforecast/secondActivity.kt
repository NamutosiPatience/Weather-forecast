package app.example.victor.weatherforecast

import android.support.v7.app.AppCompatActivity
import android.os.Bundle
import android.view.View
import android.webkit.WebView
import android.webkit.WebViewClient

class secondActivity : AppCompatActivity() {
    private val View: WebView? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_second)
        val View =findViewById<WebView>(R.id.website)
        View?.webViewClient = WebViewClient()
        View?.loadUrl("https://www.ventusky.com/")
        val webSettings = View?.settings
        webSettings?.javaScriptEnabled = true
    }

    override fun onBackPressed() {
        if (View!!.canGoBack()) {
            View.goBack()
        } else {
            super.onBackPressed()
        }
    }
}




